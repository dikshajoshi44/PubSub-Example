package com.dikshaJ.pubSub.PubSub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PubSubApplicationTests {

	@Test
	void contextLoads() {
	}

}
