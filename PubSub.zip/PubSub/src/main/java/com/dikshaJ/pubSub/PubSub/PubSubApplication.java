package com.dikshaJ.pubSub.PubSub;

import com.dikshaJ.pubSub.PubSub.DTO.Message;
import com.dikshaJ.pubSub.PubSub.Service.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PubSubApplication {

	public static void main(String[] args) {

		PubSubService pubSubService = PubSubService.getInstance();

		Publisher javaPub1 = new PublisherImp();
		Publisher pyhtonPub2 = new PublisherImp();

		Subscriber javaSub1 = new SubscriberImp();
		Subscriber javaSub2 = new SubscriberImp();
		Subscriber pythonSub3 = new SubscriberImp();

		Message javaMessage1 = new Message("java", "Hi we are working on java 1");
		Message javaMessage2 = new Message("python", "Hi we are working on python 2");
		Message pythonMessage3 = new Message("java", "Hi we are working on java 3");
		Message pythonMessage4 = new Message("python", "Hi we are working on python 4");

		javaPub1.publish(javaMessage1);
		javaPub1.publish(javaMessage2);

		pyhtonPub2.publish(pythonMessage3);
		pyhtonPub2.publish(pythonMessage4);

		javaSub1.addSubscriber("java");
		javaSub2.addSubscriber("java");
		pythonSub3.addSubscriber("python");

		pubSubService.broadCast();

		System.out.println("Messages of Java Subscriber are: ");
		javaSub1.printMessages();

		System.out.println("\nMessages of Python Subscriber are: ");
		pythonSub3.printMessages();







	}

}
